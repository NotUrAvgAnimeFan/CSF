Assignment 1 MS1-
PARTNERS: Ricardo Morales Gonzalez, Ana Kuri
CONTRIBUTIONS:
We both worked in equal parts by coding and figuring out solutions while on zoom. This
made it so that we could work in real time and contribute the same amount of effort.


Assignment 1 MS2 -
PARTNERS: Ricardo Morales Gonzalez, Ana Kuri
CONTRIBUTIONS:
As in MS1, we both worked in realtime with Ricardo writing the code and Ana checking and
correcting the logic as well as searching how to solve various problems. Prior to submission
Ana wrote extra tests as well as added comments to our code while Ricardo worked on fixing
the last few bugs in the program. As a result we both worked and contributed the same amount
of effort towards the completion of the homework.
