Assignment 1 MS1-
PARTNERS: Ricardo Morales Gonzalez, Ana Kuri
CONTRIBUTIONS:
We both worked in equal parts by coding and figuring out solutions while on zoom. This
made it so that we could work in real time and contribute the same amount of effort.
