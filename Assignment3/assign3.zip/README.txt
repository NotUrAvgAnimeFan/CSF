README for CSF Assignment 3 Milestone 2
Conains contributions

--Ricardo Morales Gonzalez rmorale5@jhu.edu
--Ana Kuri akuri1@jhu.edu


We decided to work on this project as much as we could together while
in a zoom session. As such we both contributed an equal amount
to the development of this homework and at this current (2nd) milestone.
The only things we did separately was just general bug fixing but not
much progress was made after the initial completion of the homework.
